const express = require("express");
const router = express.Router();

const {
    getStudents,
    createStudent
} = require("../controller/controller");

router.get("/students", getStudents);

router.post("/students", createStudent);

module.exports = router;