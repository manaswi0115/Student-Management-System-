let students = [];

async function addStudent() {

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const course = document.getElementById("course").value;
    const age = document.getElementById("age").value;
    const phone = document.getElementById("phone").value;

    if (!name || !email || !course || !age || !phone) {
        alert("Please fill all fields");
        return;
    }

    try {

        const response = await fetch("http://localhost:5000/api/students", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                name,
                email,
                course,
                age,
                phone
            })
        });

          if(response.ok){
        alert("✅ Student Added Successfully!");
    }

} catch(error) {

    alert("❌ Error Adding Student");
    console.error(error);
}

        const data = await response.json();

        alert("Student Added Successfully");

        document.getElementById("name").value = "";
        document.getElementById("email").value = "";
        document.getElementById("course").value = "";
        document.getElementById("age").value = "";
        document.getElementById("phone").value = "";

        console.log(data);

    }