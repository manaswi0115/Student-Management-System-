const express = require("express");
const connectDB = require("./configure/db");

const {
    getStudents,
    createStudent
} = require("./controller/controller");


const studentRoutes = require("./routes/studentroutes");

const app = express();

connectDB();

app.use(express.json());

app.use("/api", studentRoutes);

app.get("/", (req, res) => {
    res.send("Student Management API Running");
});

const PORT = 5000;

// 👇 इथे Add Student API add करायची
app.post("/students", async(req, res) => {
    try {
        const student = new Student(req.body);
        await student.save();
        res.json(student);
    } catch(error) {
        res.status(500).json({ message: error.message });
    }
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});